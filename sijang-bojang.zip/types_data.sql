-- Types 데이터 삽입 (코스 분류용)
INSERT INTO types (type_id, name) VALUES
(1, '가족이랑 가기 좋은 코스'),
(2, '연인과 가기 좋은 코스');
