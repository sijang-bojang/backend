INSERT INTO types (type_id, name) VALUES
                                      (1, '가족'),
                                      (2, '연인');