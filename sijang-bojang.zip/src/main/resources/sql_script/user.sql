INSERT INTO users (user_id, username, email, password, total_reward, exp)
VALUES (1, '엄태은', 'xodms3320@o.cnu.ac.kr', '1234', 0, 0);